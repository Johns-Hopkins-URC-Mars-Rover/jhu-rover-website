from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():

    publisher = Node(
        package="subpub",
        executable="pub",
        name="num_pub",
        output="screen",
        )
    
    subscriber = Node(
        package="subpub",
        executable="sub",
        name="num_sub",
        output="screen",
        )

    return LaunchDescription([
        subscriber,
        publisher
        ])