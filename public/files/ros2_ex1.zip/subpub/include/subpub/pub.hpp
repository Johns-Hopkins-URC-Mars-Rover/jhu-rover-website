#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/u_int32.hpp>

class publisher : public rclcpp::Node {
private:
    rclcpp::Publisher<std_msgs::msg::UInt32>::SharedPtr pub;
public:
    publisher( const std::string& name );
    void publish( uint32_t x );
};