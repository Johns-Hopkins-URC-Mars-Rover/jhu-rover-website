#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/u_int32.hpp>

class subscriber : public rclcpp::Node{
private:
    rclcpp::Subscription<std_msgs::msg::UInt32>::SharedPtr sub;
public:
    subscriber( const std::string& name );
    void callback( const std_msgs::msg::UInt32& x );
};