#include <subpub/sub.hpp>

int main( int argc, char** argv ) {
  rclcpp::init( argc, argv);

  // create a multi-threaded executor
  rclcpp::executors::MultiThreadedExecutor executor;

  // instantiate our subscriber node
  auto sub = std::make_shared<subscriber>( "sub_node" );

  // add our node and spin until Ctrl+C
  executor.add_node(sub);
  executor.spin();

  // clean up
  rclcpp::shutdown();
  return 0;
}