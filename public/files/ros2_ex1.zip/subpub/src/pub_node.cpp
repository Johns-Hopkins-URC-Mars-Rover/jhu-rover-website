#include <subpub/pub.hpp>

int main( int argc, char** argv) {
  rclcpp::init( argc, argv );

  // instantiate our publisher node
  publisher publisher( "pub_node" );

  // publish at 2 Hz
  rclcpp::Rate rate(2);

  // publish until we do Ctrl+C
  while( rclcpp::ok() ) {
    publisher.publish( 25 );
    rate.sleep();
  }

  // clean up
  rclcpp::shutdown();
  return 0;
}
