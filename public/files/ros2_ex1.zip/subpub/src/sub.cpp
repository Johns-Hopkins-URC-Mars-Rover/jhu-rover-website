#include <subpub/sub.hpp>

using namespace std::chrono_literals;

subscriber::subscriber( const std::string& name ): Node(name){
    sub = create_subscription<std_msgs::msg::UInt32>("num_topic", 10,
        std::bind(&subscriber::callback, this, std::placeholders::_1 ) );
}

void subscriber::callback( const std_msgs::msg::UInt32& num ){
    std::cout << "[sub] Heard '" << num.data << "'" << std::endl;
}