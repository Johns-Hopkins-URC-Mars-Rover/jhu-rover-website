#include <subpub/pub.hpp>

using namespace std::chrono_literals;

publisher::publisher( const std::string& name ) : Node( name ) {
    pub = create_publisher<std_msgs::msg::UInt32>("num_topic", 10);
}

void publisher::publish( uint32_t x ){
    std_msgs::msg::UInt32 num;
    num.data = x;
    // this publish is the rclcpp publisher class's publish function
    pub->publish( num );
    std::cout << "[pub] Published '" << num.data << "'" << std::endl;
}